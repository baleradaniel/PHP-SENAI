<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>CRUD Funcionários</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>
    <nav>
        <ul>
            <li><a href="index.php">Início</a></li>
            <li><a href="criar.php">Cadastrar Funcionário</a></li>
            <li><a href="ler.php">Listar Funcionários</a></li>
        </ul>
    </nav>
</header>
<hr>
